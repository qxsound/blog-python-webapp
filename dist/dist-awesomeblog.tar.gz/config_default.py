# !usr/bin/env python
# -*- coding:utf8 -*-

configs = {
    'db': {
        'host': '127.0.0.1',
        'port': '3306',
        'user': 'root',
        'password': 'root',
        'database': 'awesomeblog',
    },
    'session': {
        'secret': 'AwEsOmEbLoG'
    }
}