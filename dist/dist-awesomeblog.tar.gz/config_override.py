# !usr/bin/env python
# -*- coding:utf8 -*-

configs = {
    'db': {
        'host': '127.0.0.1'
    }
}